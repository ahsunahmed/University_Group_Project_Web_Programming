

<?php
    require_once 'includes/db.php';
    require_once 'includes/header.php';
    require_once 'includes/nav.php';
?>



    <!--about-banner part start-->
    <section id="about-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-banner-title">
                        <h3>bokking a restaurant table</h3>
                        <ul>
                            <li><i class="fas fa-home"></i><a href="index.php">home</a></li>
                            <li><span>/</span></li>
                            <li><a href="#"><span>Reservation</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--about-banner part end-->



    <!--bookling-form part start-->
    <section id="booking-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="booking-title">
                        <h2>Book A Table</h2>
                        <p>Some Trendy And Popular Courses Offerd</p>
                    </div>
                    <div class="main-booking-form">
                        <p>Monday- Friday: <span>08am - 12pm</span> </p>
                        <p> Saturday - Sunday: <span>10am -11pm</span></p>

                        <form action="resrvation_post.php" method="post">
                            <input class="name" type="text" placeholder="Name" name ="name">
                            <input class="email" type="email" placeholder="Email" name ="email">
                            <input class="number" type="text" placeholder="Telephone Number" name ="phone">
                            <input class="number" type="text" placeholder="Date" name ="date">
                            <input class="number" type="text" placeholder="Time" name ="time">
                            </br>
                            </br>
                            <button type="submit" class="btn btn-success">SUBMIT</button>
                            
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--bookling-form part end-->

    <?php
    require_once 'includes/fotter.php';

?>

    <!--java-script link-->
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>
