
<?php
    require_once 'includes/header.php';
    require_once 'includes/nav.php';
?>
    <!--about-banner part start-->
    <section id="about-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-banner-title">
                        <h3>about us</h3>
                        <ul>
                            <li><i class="fas fa-home"></i><a href="#">home</a></li>
                            <li><span>/</span></li>
                            <li><a href="#"><span>about</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--about-banner part end-->


    <!--history part start-->
    <section id="history">
        <div class="history-banner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-xl-7">
                        <div class="history-title">
                            <h2>Restaurant History</h2>
                            <h6>Accumsan quis, vulputate sit amet sapien. Curabitur euismod vulputate nulla, non fringilla neque condimentum placerat.Integer egestas ullamcorper purus. </h6>
                            <p>Pellentesque habitant morbi tristique senectus netus et malesuada fames turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris Eonec eu ribero sit amet quam egestas semper. Aenean are ultricies mi vitae est tristique senectus et netus et malesuada placerat leo. </p>

                            <div class="his-btn">
                                <a href="#">read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--history part end-->

    <!--food-zone part start-->
    <section id="food-zone">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone1.png" alt="food-zone1.png">
                        <h4>Dinner & Dessert</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone2.png" alt="food-zone2.png">
                        <h4>coffe zone</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone3.png" alt="food-zone3.png">
                        <h4>ice shakes</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone4.png" alt="food-zone4.png">
                        <h4>fresh food</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone5.png" alt="food-zone5.png">
                        <h4>breakfast</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="food-zone-box">
                        <img src="images/food-zone6.png" alt="food-zone6.png">
                        <h4>ice drinks</h4>
                        <p>Beetroot water spinach okra water chestnut ricebean pea.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--food-zone part end-->

    



    <!--chef-exprience part start-->
    <section id="chef-exprience">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="chef-title">
                        <h2>Experienced Chefs</h2>
                        <p>Some Special Teachers From The Industry!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef1.jpg" alt="chef1">
                        <div class="chef-box-title">
                            <h4>
                                Enathon Jackson
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef2.jpg" alt="chef2.jpg">
                        <div class="chef-box-title">
                            <h4>
                                Eliana De suja
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef3.jpg" alt="chef3.jpg">
                        <div class="chef-box-title">
                            <h4>
                                Devid Vaskar
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef4.jpg" alt="chef4.jpg">
                        <div class="chef-box-title">
                            <h4>
                                Enathon Jackson
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef2.jpg" alt="chef2.jpg">
                        <div class="chef-box-title">
                            <h4>
                                Eliana De suja
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef1.jpg" alt="chef1.jpg">
                        <div class="chef-box-title">
                            <h4>
                                Devid Vaskar
                            </h4>
                            <p>head of chef</p>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--chef-exprience part end-->

    <!--about-clint part start-->
    <section id="about-clint">
        <div class="clint-over">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="clint-title">
                            <h2>What Clients Say</h2>
                            <p>Latest News Updates You Dont Miss Out!</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="about-clint-main">
                            <div class="about-clint-main-title">
                                <p>"This is the best Restaurant in the world"</p>
                                <h5> Proin sodales dapibus magna, et porta leo convallis sed. Duis tincidunt libero ut neque mollis dignissim. Nullam ultricies sit amet quam non iaculis. Curabitur convallis nulla non nibh aliquet rhoncus. Donec at tempus felis.</h5>
                                <img src="images/clint-say.jpg" alt="clint-say.jpg">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--about-clint part end-->
<?php

    require_once 'includes/fotter.php';
?>
