<?php
    require_once 'includes/db.php';
    require_once 'includes/header.php';
    require_once 'includes/nav.php';


    $banner_select_query = "SELECT banner_main_title, banner_sub_title, banner_sub_dis FROM banners";
    $banner_data_db = mysqli_query($db_connect, $banner_select_query );


    $chefs_select_query = "SELECT name_one, title_one, specialist_one, name_two, title_two, specialist_two, name_three, title_three, specialist_three FROM chefs";
    $chefs_data_db = mysqli_query($db_connect, $chefs_select_query );

    $clients_select_query = "SELECT clint_title, clint_txt FROM clients";
    $clients_data_db = mysqli_query($db_connect, $clients_select_query );

    

?>

<!--menu-filter part start-->
<section id="menu-filter">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-title">
                        <h2>offerd menu</h2>
                        <p>some trendy and popular courses offerd</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="menu-filter-title">
                        <ul>
                            <li><button data-filter=".all">all items</button></li>
                            <li><button data-filter=".pizza">pizza</button></li>
                            <li><button data-filter=".soup">soup</button></li>
                            <li><button data-filter=".kabab">kabab</button></li>
                            <li><button data-filter=".stack">stack</button></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
        <div class="food">
            <div class="row">
                <div class="col-lg-12">
                    <div class="food-filter">
                        <div class="main-food">

                            <div class="row filter-js">
                                <div class="col-lg-6 col-md-6 mix all kabab">
                                    <div class="food-box">
                                        <img src="images/menu1.jpg" alt="menu1.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all kabab">
                                    <div class="food-box">
                                        <img src="images/menu2.jpg" alt="menu2.jpg">
                                        <div class="food-box-title">
                                            <h4>roasted prawns coriander</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza">
                                    <div class="food-box">
                                        <img src="images/menu3.jpg" alt="menu3.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza">
                                    <div class="food-box">
                                        <img src="images/menu4.jpg" alt="menu4.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza stack">
                                    <div class="food-box">
                                        <img src="images/menu5.jpg" alt="menu5.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all soup stack">
                                    <div class="food-box">
                                        <img src="images/menu6.jpg" alt="menu6.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--menu-filter part end-->

<?php
    require_once 'includes/fotter.php';
?>