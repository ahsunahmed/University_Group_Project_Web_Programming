<?php
session_start();
require_once 'includes/db.php';


$banner_main_title = $_POST['banner_main_title'];
$banner_sub_title = $_POST['banner_sub_title'];
$banner_sub_dis = $_POST['banner_sub_dis'];


$banner_insert_query = "INSERT INTO `banners`(banner_main_title, banner_sub_title, banner_sub_dis) VALUES ('$banner_main_title','$banner_sub_title','$banner_sub_dis')";
        mysqli_query($db_connect, $banner_insert_query);
        $_SESSION['banner_inset_news'] = 'Banner title Insert Successfully';
        header('location:restura_admin.php');
        
?>