<?php
session_start();
require_once 'includes/db.php'; // 1st database connection

$id =  $_GET['id'];
$resrvation_delete = "DELETE FROM resrvation WHERE id= $id";
$delete = mysqli_query($db_connect,$resrvation_delete);

$_SESSION['resrvation_delete'] = 'Deleted resrvation one sucessfully';
header('location:restura_admin.php');

?>