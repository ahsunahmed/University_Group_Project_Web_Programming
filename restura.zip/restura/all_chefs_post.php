<?php
    session_start();
    require_once 'includes/db.php';

    

    $name_one = $_POST['name_one'];
    $title_one = $_POST['title_one'];
    $specialist_one = $_POST['specialist_one'];
    $name_two = $_POST['name_two'];
    $title_two = $_POST['title_two'];
    $specialist_two = $_POST['specialist_two'];
    $name_three = $_POST['name_three'];
    $title_three = $_POST['title_three'];
    $specialist_three = $_POST['specialist_three'];

    $name_four = $_POST['name_four'];
    $title_four = $_POST['title_four'];
    $specialist_four = $_POST['specialist_four'];
    $name_5th = $_POST['name_5th'];
    $title_5th = $_POST['title_5th'];
    $specialist_5th = $_POST['specialist_5th'];
    $name_6th = $_POST['name_6th'];
    $title_6th = $_POST['title_6th'];
    $specialist_6th = $_POST['specialist_6th'];
    $name_7th = $_POST['name_7th'];
    $title_7th = $_POST['title_7th'];
    $specialist_7th = $_POST['specialist_7th'];
    $name_8th = $_POST['name_8th'];
    $title_8th = $_POST['title_8th'];
    $specialist_8th = $_POST['specialist_8th'];



    $all_chefs_insert = "INSERT INTO `all_chefs`(name_one, title_one, specialist_one, name_two, title_two, specialist_two, name_three, title_three, specialist_three, name_four, title_four, specialist_four, name_5th, title_5th, specialist_5th, name_6th, title_6th, specialist_6th, name_7th, title_7th, specialist_7th, name_8th, title_8th, specialist_8th) VALUES ('$name_one', '$title_one', '$specialist_one', '$name_two', '$title_two', '$specialist_two', '$name_three', '$title_three', '$specialist_three', '$name_four', '$title_four', '$specialist_four', '$name_5th', '$title_5th', '$specialist_5th', '$name_6th', '$title_6th', '$specialist_6th', '$name_7th', '$title_7th', '$specialist_7th', '$name_8th', '$title_8th', '$specialist_8th')";
    $all_chefs_insert_query = mysqli_query($db_connect,$all_chefs_insert);
    $_SESSION['all_chefs_news'] = 'All Chefs Data updated successfully';
    header('location:restura_admin.php');

