<?php
    session_start();
    require_once 'includes/db.php';

    

    $name_one = $_POST['name_one'];
    $title_one = $_POST['title_one'];
    $specialist_one = $_POST['specialist_one'];
    $name_two = $_POST['name_two'];
    $title_two = $_POST['title_two'];
    $specialist_two = $_POST['specialist_two'];
    $name_three = $_POST['name_three'];
    $title_three = $_POST['title_three'];
    $specialist_three = $_POST['specialist_three'];

    $chefs_insert = "INSERT INTO `chefs`(name_one, title_one, specialist_one, name_two, title_two, specialist_two, name_three, title_three, specialist_three) VALUES ('$name_one', '$title_one', '$specialist_one', '$name_two', '$title_two', '$specialist_two', '$name_three', '$title_three', '$specialist_three')";
    $chefs_insert_query = mysqli_query($db_connect,$chefs_insert);
    $_SESSION['chefs_news'] = 'Chefs Data updated successfully';
    header('location:restura_admin.php');





?>