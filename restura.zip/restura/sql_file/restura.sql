-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2024 at 03:48 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restura`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_chefs`
--

CREATE TABLE `all_chefs` (
  `id` int(100) NOT NULL,
  `name_one` varchar(100) NOT NULL,
  `title_one` varchar(100) NOT NULL,
  `specialist_one` varchar(100) NOT NULL,
  `name_two` varchar(100) NOT NULL,
  `title_two` varchar(100) NOT NULL,
  `specialist_two` varchar(100) NOT NULL,
  `name_three` varchar(100) NOT NULL,
  `title_three` varchar(100) NOT NULL,
  `specialist_three` varchar(100) NOT NULL,
  `name_four` varchar(100) NOT NULL,
  `title_four` varchar(100) NOT NULL,
  `specialist_four` varchar(100) NOT NULL,
  `name_5th` varchar(100) NOT NULL,
  `title_5th` varchar(100) NOT NULL,
  `specialist_5th` varchar(100) NOT NULL,
  `name_6th` varchar(100) NOT NULL,
  `title_6th` varchar(100) NOT NULL,
  `specialist_6th` varchar(100) NOT NULL,
  `name_7th` varchar(100) NOT NULL,
  `title_7th` varchar(100) NOT NULL,
  `specialist_7th` varchar(100) NOT NULL,
  `name_8th` varchar(100) NOT NULL,
  `title_8th` varchar(100) NOT NULL,
  `specialist_8th` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `all_chefs`
--

INSERT INTO `all_chefs` (`id`, `name_one`, `title_one`, `specialist_one`, `name_two`, `title_two`, `specialist_two`, `name_three`, `title_three`, `specialist_three`, `name_four`, `title_four`, `specialist_four`, `name_5th`, `title_5th`, `specialist_5th`, `name_6th`, `title_6th`, `specialist_6th`, `name_7th`, `title_7th`, `specialist_7th`, `name_8th`, `title_8th`, `specialist_8th`) VALUES
(1, 'klhlh', 'klhk', 'hoi', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `banner_main_title` text NOT NULL,
  `banner_sub_title` text NOT NULL,
  `banner_sub_dis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `banner_main_title`, `banner_sub_title`, `banner_sub_dis`) VALUES
(20, 'KhaiDai', 'BEST FOOD SINCE - NOW', '');

-- --------------------------------------------------------

--
-- Table structure for table `chefs`
--

CREATE TABLE `chefs` (
  `id` int(11) NOT NULL,
  `name_one` varchar(100) NOT NULL,
  `title_one` varchar(100) NOT NULL,
  `specialist_one` varchar(100) NOT NULL,
  `name_two` varchar(100) NOT NULL,
  `title_two` varchar(100) NOT NULL,
  `specialist_two` varchar(100) NOT NULL,
  `name_three` varchar(100) NOT NULL,
  `title_three` varchar(100) NOT NULL,
  `specialist_three` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chefs`
--

INSERT INTO `chefs` (`id`, `name_one`, `title_one`, `specialist_one`, `name_two`, `title_two`, `specialist_two`, `name_three`, `title_three`, `specialist_three`) VALUES
(10, 'albir', 'alm', 'dvd', 'iffat', 'jhan', 'edvwvd', 'fahmida', 'ahamed', 'dfsda');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `clint_title` varchar(100) NOT NULL,
  `clint_txt` varchar(100) NOT NULL,
  `clint_title_2nd` varchar(100) NOT NULL,
  `clint_txt_2nd` varchar(100) NOT NULL,
  `clint_title_3rd` varchar(100) NOT NULL,
  `clint_txt_3rd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `clint_title`, `clint_txt`, `clint_title_2nd`, `clint_txt_2nd`, `clint_title_3rd`, `clint_txt_3rd`) VALUES
(7, 'iffat', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the ', 'Fahmida', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the ', 'albir', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the ');

-- --------------------------------------------------------

--
-- Table structure for table `resrvation`
--

CREATE TABLE `resrvation` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resrvation`
--

INSERT INTO `resrvation` (`id`, `name`, `email`, `phone`, `date`, `time`) VALUES
(19, 'albir alam rakib', 'albir@gail.com', '011223344', '15/9/2024', 'dinner');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_chefs`
--
ALTER TABLE `all_chefs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chefs`
--
ALTER TABLE `chefs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resrvation`
--
ALTER TABLE `resrvation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_chefs`
--
ALTER TABLE `all_chefs`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `chefs`
--
ALTER TABLE `chefs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `resrvation`
--
ALTER TABLE `resrvation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
