
<?php
    require_once 'includes/db.php';
    require_once 'includes/header.php';
    require_once 'includes/nav.php';


    $banner_select_query = "SELECT banner_main_title, banner_sub_title, banner_sub_dis FROM banners";
    $banner_data_db = mysqli_query($db_connect, $banner_select_query );


    $chefs_select_query = "SELECT name_one, title_one, specialist_one, name_two, title_two, specialist_two, name_three, title_three, specialist_three FROM chefs";
    $chefs_data_db = mysqli_query($db_connect, $chefs_select_query );

    $clients_select_query = "SELECT clint_title, clint_txt, clint_title_2nd, clint_txt_2nd, clint_title_3rd, clint_txt_3rd FROM clients";
    $clients_data_db = mysqli_query($db_connect, $clients_select_query );
    

?>
    <!--banner part start-->
    <section id="banner">
        <div class="banner-slide">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-title">

                            <?php
                                foreach($banner_data_db as $banner_data):
                            ?>

                            <h1><?=$banner_data['banner_main_title'];?></h1>
                            <h2><?=$banner_data['banner_sub_title'];?></h2>
                            <p><?=$banner_data['banner_sub_dis'];?></p>
                            
                            <?php endforeach ;?>
                           
                            

                            <div class="resr-btn">
                                <a href="Reservation.php">
                                    <span>resrvation</span>
                                </a>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--banner part end-->

    <!--history part start-->
    <section id="history">
        <div class="history-banner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-xl-7">
                        <div class="history-title">
                            <h2>Restaurant History</h2>
                            <h6>Accumsan quis, vulputate sit amet sapien. Curabitur euismod vulputate nulla, non fringilla neque condimentum placerat.Integer egestas ullamcorper purus. </h6>
                            <p>Pellentesque habitant morbi tristique senectus netus et malesuada fames turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris Eonec eu ribero sit amet quam egestas semper. Aenean are ultricies mi vitae est tristique senectus et netus et malesuada placerat leo. </p>

                            <div class="his-btn">
                                <a href="#">read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--history part end-->

    <!--menu-filter part start-->
    <section id="menu-filter">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-title">
                        <h2>offerd menu</h2>
                        <p>some trendy and popular courses offerd</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="menu-filter-title">
                        <ul>
                            <li><button data-filter=".all">all items</button></li>
                            <li><button data-filter=".pizza">pizza</button></li>
                            <li><button data-filter=".soup">soup</button></li>
                            <li><button data-filter=".kabab">kabab</button></li>
                            <li><button data-filter=".stack">stack</button></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
        <div class="food">
            <div class="row">
                <div class="col-lg-12">
                    <div class="food-filter">
                        <div class="main-food">

                            <div class="row filter-js">
                                <div class="col-lg-6 col-md-6 mix all kabab">
                                    <div class="food-box">
                                        <img src="images/menu1.jpg" alt="menu1.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all kabab">
                                    <div class="food-box">
                                        <img src="images/menu2.jpg" alt="menu2.jpg">
                                        <div class="food-box-title">
                                            <h4>roasted prawns coriander</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza">
                                    <div class="food-box">
                                        <img src="images/menu3.jpg" alt="menu3.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza">
                                    <div class="food-box">
                                        <img src="images/menu4.jpg" alt="menu4.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all pizza stack">
                                    <div class="food-box">
                                        <img src="images/menu5.jpg" alt="menu5.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 mix all soup stack">
                                    <div class="food-box">
                                        <img src="images/menu6.jpg" alt="menu6.jpg">
                                        <div class="food-box-title">
                                            <h4>salad with vagitable</h4>
                                            <p>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate cumque doloribus porro
                                            </p>
                                            <div class="menu-price">
                                                <span>$50</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--menu-filter part end-->

    <!--bookling-form part start-->
    <section id="booking-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="booking-title">
                        <h2>Book A Table</h2>
                        <p>Some Trendy And Popular Courses Offerd</p>
                    </div>
                    <div class="main-booking-form">
                        <p>Monday- Friday: <span>08am - 12pm</span> </p>
                        <p> Saturday - Sunday: <span>10am -11pm</span></p>

                        <form action="resrvation_post.php" method="post">
                            <input class="name" type="text" placeholder="Name" name ="name">
                            <input class="email" type="email" placeholder="Email" name ="email">
                            <input class="number" type="text" placeholder="Telephone Number" name ="phone">
                            <input class="number" type="text" placeholder="Date" name ="date">
                            <input class="number" type="text" placeholder="Time" name ="time">
                            </br>
                            </br>
                            <button type="submit" class="btn btn-success">SUBMIT</button>
                            
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--bookling-form part end-->

    <!--chef part start-->
    <section id="chef">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="chef-title">
                        <h2>Experienced Chefs</h2>
                        <p>Some Special Teachers From The Industry!</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef1.jpg" alt="chef1">
                        <div class="chef-box-title">
                           <?php
                            foreach($chefs_data_db as $chefs_data){
                           ?> 
                        

                            <h4>
                                <?= $chefs_data['name_one']?>
                            </h4>
                            <p><?= $chefs_data['title_one']?></p>
                            <p><?= $chefs_data['specialist_one']?></p>

                            <?php }; ?>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef2.jpg" alt="chef2.jpg">
                        <div class="chef-box-title">
                        <?php
                            foreach($chefs_data_db as $chefs_data){
                           ?> 
                        

                            <h4>
                                <?= $chefs_data['name_two']?>
                            </h4>
                            <p><?= $chefs_data['title_two']?></p>
                            <p><?= $chefs_data['specialist_two']?></p>

                            <?php }; ?>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="chef-box">
                        <img src="images/chef3.jpg" alt="chef3.jpg">
                        <div class="chef-box-title">
                        <?php
                            foreach($chefs_data_db as $chefs_data){
                           ?> 
                        

                            <h4>
                                <?= $chefs_data['name_three']?>
                            </h4>
                            <p><?= $chefs_data['title_three']?></p>
                            <p><?= $chefs_data['specialist_three']?></p>

                            <?php }; ?>
                            <div class="chef-icon">
                                <ul>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                </ul>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--chef part end-->

    <!--clint part start-->
    <section id="clint">
        <div class="clint-over">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="clint-title">
                            
                            <h2>What Clients Say</h2>
                            <p>Latest News Updates You Dont Miss Out!</p>
                        
                        </div>
                    </div>
                </div>
                <div class="clint-slide ">
                    <div class="row">
                        
                        <div class="col-lg-4">
                            <div class="clind-say ">
                            <?php foreach($clients_data_db as $clint_single_data): ?>
                                <h5><?=$clint_single_data['clint_title']?></h5>
                                <p><?=$clint_single_data['clint_txt']?> </p>
                            <?php endforeach; ?>
                                <img src="images/clint-say.jpg" alt="clint-say.jpg">
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="clind-say ">
                            <?php foreach($clients_data_db as $clint_single_data): ?>
                                <h5><?=$clint_single_data['clint_title_2nd']?></h5>
                                <p><?=$clint_single_data['clint_txt_2nd']?> </p>
                            <?php endforeach; ?>
                                <img src="images/clint-say.jpg" alt="clint-say.jpg">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="clind-say ">
                            <?php foreach($clients_data_db as $clint_single_data): ?>
                                <h5><?=$clint_single_data['clint_title_3rd']?></h5>
                                <p><?=$clint_single_data['clint_txt_3rd']?> </p>
                            <?php endforeach; ?>
                                <img src="images/clint-say.jpg" alt="clint-say.jpg">
                            </div>
                        </div>
                        
                        
                    </div>
                </div>

            </div>
        </div>

    </section>
    <!--clint part end-->
    

    

    <?php
        require_once 'includes/fotter.php';
    ?>
