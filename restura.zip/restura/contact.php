
<?php
    require_once 'includes/db.php';
    require_once 'includes/header.php';
    require_once 'includes/nav.php';


    $banner_select_query = "SELECT banner_main_title, banner_sub_title, banner_sub_dis FROM banners";
    $banner_data_db = mysqli_query($db_connect, $banner_select_query );


    $chefs_select_query = "SELECT name_one, title_one, specialist_one, name_two, title_two, specialist_two, name_three, title_three, specialist_three FROM chefs";
    $chefs_data_db = mysqli_query($db_connect, $chefs_select_query );

    $clients_select_query = "SELECT clint_title, clint_txt FROM clients";
    $clients_data_db = mysqli_query($db_connect, $clients_select_query );
    

?>

<!--history part start-->
<section id="history">
        <div class="history-banner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="history-title">
                            <div class="main-booking-form">
                            <form action="" method="post">
                            
                            <input class="email con_email" type="email" placeholder="Email" name="email">
                            <div class="con_text">
                              <textarea class="form-control" id="exampleFormControlTextarea1"type="email" placeholder="message" name="Textarea" rows="5"></textarea>
                            </div>
                            
                            <br>
                            <br>
                            <button type="submit" class="btn btn-success">SUBMIT</button>
                            
                        </form>
                            </div>       
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--history part end-->









<?php
    require_once 'includes/fotter.php';
?>