<?php
    session_start();
    require_once 'includes/db.php';

    $delete_chefs_all = "DELETE FROM chefs";
    $delete_chefs = mysqli_query($db_connect,$delete_chefs_all);
    $_SESSION['chefes_delete'] = 'Chefs Part Deleted Successfully';
        header('location:restura_admin.php');
    
?>