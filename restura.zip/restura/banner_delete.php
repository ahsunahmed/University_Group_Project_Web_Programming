<?php
    session_start();
    require_once 'includes/db.php';

    $delete_user_all = "DELETE FROM banners ";
    $banner_delete = mysqli_query($db_connect,$delete_user_all);

    if($banner_delete){
        $_SESSION['banner_delete_news'] = 'Deleted Successfully';
        header('location:restura_admin.php');
     }
    else{
        echo "undeleted data"; 
    }
?>