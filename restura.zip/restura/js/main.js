//-------- auto-counter start --------//

jQuery(document).ready(function ($) {
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });
});

//-------- auto-counter end --------//



//--------filter start--------//
var mixer = mixitup('.filter-js');
//--------filter end--------//


