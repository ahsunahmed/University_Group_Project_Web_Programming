<?php
session_start();
require_once 'includes/db.php'; // 1st database connection

$clients_delete = "DELETE FROM clients";
$delete = mysqli_query($db_connect,$clients_delete);

$_SESSION['clients_delete'] = 'Deleted clients review sucessfully';
header('location:restura_admin.php');

?>