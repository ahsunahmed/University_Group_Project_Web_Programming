<?php
session_start();
    require_once "includes/db.php";
    require_once "includes/admin_header.php";

    $resrvation_select_query = "SELECT id, name, email, phone, date, time FROM resrvation";
    $resrvation_db = mysqli_query($db_connect, $resrvation_select_query );
?>
<div class="container">
    <div class=""></div>
</div>
<div class="container">
    <!-- banner part start -->
    <div class="col-lg-12">
        <div class="card mt-5">
            <div class="card-header bg-success ">
                <h4>Banner </h4>

            </div>
            <div class="card-body">
                <form action="banner_post.php" method="post">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="form-group">
                            <label class="col-form-label">Banner Main Title</label>

                            <?php
                                                        if(isset($_SESSION['banner_delete_news'])){
                                                    ?>
                            <div class="alert alert-danger">
                                <?php
                                                        echo $_SESSION['banner_delete_news'];
                                                        unset($_SESSION['banner_delete_news']);
                                                        ?>
                            </div>

                            <?php }
                                                ?>

                            <?php
                                                        if(isset($_SESSION['banner_inset_news'])){
                                                    ?>
                            <div class="alert alert-success">
                                <?php
                                                        echo $_SESSION['banner_inset_news'];
                                                        unset($_SESSION['banner_inset_news']);
                                                        ?>
                            </div>

                            <?php }
                                                ?>



                            <input class="form-control" type="text" placeholder="" name="banner_main_title">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Banner Sub Title</label>
                            <input class="form-control" type="text" placeholder="" name="banner_sub_title">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Banner escription</label>
                            <input class="form-control" type="text" placeholder="" name="banner_sub_dis">
                        </div>

                        <input class="btn btn-success" type="submit">
                        <a class="btn btn-success" href="banner_delete.php">Delete</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <!-- banner part end -->
    <!-- resrvation part start -->
    <div class="col-lg-12">
        <div class="card mt-5 mb-5">
            <div class="card-header bg-success ">
                <h4>resrvation </h4>
            </div>
            <div class="card-body">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <?php
                                                        if(isset($_SESSION['resvation_news'])){
                                                    ?>
                    <div class="alert alert-success">
                        <?php
                                                        echo $_SESSION['resvation_news'];
                                                        unset($_SESSION['resvation_news']);
                                                        ?>
                    </div>

                    <?php }
                                                ?>
                    <?php
                                                        if(isset($_SESSION['resrvation_delete'])){
                                                    ?>
                    <div class="alert alert-danger">
                        <?php
                                                        echo $_SESSION['resrvation_delete'];
                                                        unset($_SESSION['resrvation_delete']);
                                                        ?>
                    </div>

                    <?php }
                                                ?>

                    <table class="table table-striped">
                        <thead>
                            <tr>phone
                                <th scope="col">SL</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">phone</th>
                                <th scope="col">date</th>
                                <th scope="col">time</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php foreach($resrvation_db as $resrvation):?>
                            <tr>

                                <th scope="row"><?=$resrvation['id']?></th>
                                <td><?=$resrvation['name']?></td>
                                <td><?=$resrvation['email']?></td>
                                <td><?=$resrvation['phone']?></td>
                                <td><?=$resrvation['date']?></td>
                                <td><?=$resrvation['time']?></td>
                                <td><a class="btn btn-danger" href="resrvation_delete.php?id=<?=$resrvation['id']?>">Delete</a></td>
                            </tr>
                            <tr>

                                <?php endforeach ; ?>
                        </tbody>
                    </table>
                    <div>
                    </div>
                </div>
            </div>
               
        </div>
     
    </div>
    <!-- resrvation Part end --> 
    <!-- chefs part start -->
    <div class="col-lg-12">
        <div class="card ">
                            <div class="card-header bg-success ">
                                <h4>Chefs Part</h4>
                            </div>
                            <div class="card-body">
                                <form action="chefs_post.php" method="post">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                        <?php
                                                                if(isset($_SESSION['chefs_news'])){
                                                            ?>
                                        <div class="alert alert-success">
                                            <?php
                                                                echo $_SESSION['chefs_news'];
                                                                unset($_SESSION['chefs_news']);
                                                                ?>
                                        </div>

                                        <?php }
                                                        ?>

                                        <?php
                                                                if(isset($_SESSION['chefes_delete'])){
                                                            ?>
                                        <div class="alert alert-success">
                                            <?php
                                                                echo $_SESSION['chefes_delete'];
                                                                unset($_SESSION['chefes_delete']);
                                                                ?>
                                        </div>

                                        <?php }
                                                        ?>

                                        <div class="card-header bg-success mb-3"> 1st chefs row</div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs neme</label>
                                            <input class="form-control" type="text" placeholder="" name="name_one">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_one">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_one">
                                        </div>

                                        <div class="card-header bg-success mb-3">2nd chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_two">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_two">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_two">
                                        </div>



                                        <div class="card-header bg-success mb-3">3rd chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_three">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_three">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_three">
                                        </div>



                                        <input class="btn btn-success" type="submit">
                                        <a class="btn btn-danger" href="chefs_delete.php">Delete</a>
                                    </div>

                                </form>
                            </div>
                        </div>           
    </div>
    <!-- chefs part end -->

    <!-- clind say part start -->
    <div class="col-lg-12">
        <div class="card mt-5">
            <div class="card-header bg-success ">
                <h4>Clints Part</h4>

            </div>
            <div class="card-body">
                <form action="clint_post.php" method="post">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <?php
                                                        if(isset($_SESSION['clint_news'])){
                                                    ?>
                            <div class="alert alert-success">
                                <?php
                                                        echo $_SESSION['clint_news'];
                                                        unset($_SESSION['clint_news']);
                                                        ?>
                            </div>

                            <?php };?>

                            <?php
                                                        if(isset($_SESSION['clients_delete'])){
                                                    ?>
                            <div class="alert alert-danger">
                                <?php
                                                        echo $_SESSION['clients_delete'];
                                                        unset($_SESSION['clients_delete']);
                                                        ?>
                            </div>

                            <?php };?>
                        <div class="form-group">
                            <label class="col-form-label">Clints Title 1</label>
                            <input class="form-control" type="text" placeholder="" name="clint_title">
                        </div>
                        
                        <div class="form-group">
                            <label class="col-form-label"></label>
                            <input class="form-control" type="text" placeholder="" name="clint_txt">
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">Clints Title 2</label>
                            <input class="form-control" type="text" placeholder="" name="clint_title_2nd">
                        </div>
                        
                        <div class="form-group">
                            <label class="col-form-label"></label>
                            <input class="form-control" type="text" placeholder="" name="clint_txt_2nd">
                        </div>

                        <div class="form-group">
                            <label class="col-form-label">Clints Title 3</label>
                            <input class="form-control" type="text" placeholder="" name="clint_title_3rd">
                        </div>
                        
                        <div class="form-group">
                            <label class="col-form-label"></label>
                            <input class="form-control" type="text" placeholder="" name="clint_txt_3rd">
                        </div>
                        
                        <input class="btn btn-success" type="submit">
                        <a class="btn btn-danger" href="clint_delete.php">Delete</a>
                    </div>

                </form>
            </div>
        </div>
    </div>                                                                
    <!-- clind say part end -->

    <!-- all chefs part start -->
    <div class="col-lg-12">
        <div class="card ">
                            <div class="card-header bg-success ">
                                <h4>All Chefs</h4>
                            </div>
                            <div class="card-body">
                                <form action="all_chefs_post.php" method="post">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                                        <?php
                                                                if(isset($_SESSION['all_chefs_news'])){
                                                            ?>
                                        <div class="alert alert-success">
                                            <?php
                                                                echo $_SESSION['all_chefs_news'];
                                                                unset($_SESSION['all_chefs_news']);
                                                                ?>
                                        </div>

                                        <?php }
                                                        ?>

                                        <?php
                                                                if(isset($_SESSION['chefes_delete'])){
                                                            ?>
                                        <div class="alert alert-success">
                                            <?php
                                                                echo $_SESSION['chefes_delete'];
                                                                unset($_SESSION['chefes_delete']);
                                                                ?>
                                        </div>

                                        <?php }
                                                        ?>

                                        <div class="card-header bg-success mb-3"> 1st chefs row</div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs neme</label>
                                            <input class="form-control" type="text" placeholder="" name="name_one">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_one">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_one">
                                        </div>

                                        <div class="card-header bg-success mb-3">2nd chefs row</div>

                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_two">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_two">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_two">
                                        </div>
                                        <div class="card-header bg-success mb-3">3rd chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_three">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_three">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_three">
                                        </div>

                                        <div class="card-header bg-success mb-3">4th chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_four">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_four">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_four">
                                        </div>

                                        <div class="card-header bg-success mb-3">5th chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_5th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_5th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_5th">
                                        </div>


                                        <div class="card-header bg-success mb-3">6th chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_6th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_6th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_6th">
                                        </div>

                                        <div class="card-header bg-success mb-3">7th chefs row</div>


                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_7th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_7th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_7th">
                                        </div>

                                        <div class="card-header bg-success mb-3">8th chefs row</div>

                                        <div class="form-group">
                                            <label class="col-form-label">Chefs name</label>
                                            <input class="form-control" type="text" placeholder="" name="name_8th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Title</label>
                                            <input class="form-control" type="text" placeholder="" name="title_8th">
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label">Chefs Specialist</label>
                                            <input class="form-control" type="text" placeholder="" name="specialist_8th">
                                        </div>


                                        <input class="btn btn-success" type="submit">
                                        <a class="btn btn-danger" href="chefs_delete.php">Delete</a>
                                    </div>

                                </form>
                            </div>
                        </div>           
    </div>
    <!-- all chefs part end -->


        




    <?php
    require_once "includes/admin_fotter.php";
?>
