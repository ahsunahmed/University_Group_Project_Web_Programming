
<?php
// database_connection start
define("HOSTNAME","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE_NAME","restura");
$db_connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE_NAME);
if(mysqli_connect_errno()){
    echo "<h1> Data base connection problem </h1>";
}

?>