	
    <!-- Required Script -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Page Specific Script -->
    <script src="assets/js/nice-select.min.js"></script>

    <!-- Custom Script -->
    <script src="assets/js/custom.js"></script>
</body>


<!-- Mirrored from kamleshyadav.com/html/splashdash/html/b5/light/form.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Mar 2024 21:26:26 GMT -->
</html>