<!--fotter part start-->
<section id="fotter">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="fotter-logo">
                        <a href="#">
                            <span>r</span>estur<span>a</span>
                        </a>
                    </div>
                    <div class="fotter-txt">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>minabazar godaun dhaka bangladesh </span>
                    </div>
                    <div class="fotter-txt">
                        <i class="fas fa-phone"></i>
                        <span>ue9e 654 368</span>
                    </div>
                    <div class="fotter-txt">
                        <i class="fas fa-envelope"></i>
                        <span>mon mane nah .com</span>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="fotter-title">
                        <h5>Opening Time</h5>
                    </div>
                    <div class="fotter-time">
                        <h6>Saterday- Sunday <span>10:00</span> Am - <span>11:00 PM</span></h6>
                    </div>
                    <div class="fotter-time">
                        <h6>Saterday- Sunday <span>10:00</span> Am - <span>11:00 PM</span></h6>
                    </div>
                    <div class="fotter-time">
                        <h6>Saterday- Sunday <span>10:00</span> Am - <span>11:00 PM</span></h6>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="fotter-title">
                        <h5>The Menu</h5>
                    </div>
                    <div class="fotter-item">
                        <ul>
                            <li><a href="#">Speacial Items</a></li>
                            <li><a href="#">fresh breakfast</a></li>
                            <li><a href="#">lunch menu</a></li>
                            <li><a href="#">dinner items</a></li>
                            <li><a href="#">fresh food zone</a></li>
                            <li><a href="#">we offerd food</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
            
        </div>
    </section>
    <!--fotter part end-->




    <!--java-script link-->
    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>