<?php
session_start();
require_once 'includes/db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$date = $_POST['date'];
$time = $_POST['time'];


$resvation_insert_query =" INSERT INTO `resrvation`(name, email, phone, date, time) VALUES ('$name','$email','$phone','$date','$time')";
$resvation_data = mysqli_query($db_connect,$resvation_insert_query);
$_SESSION['resvation_news'] = 'new resvation successfully update';
header('location:reservation.php');


?>