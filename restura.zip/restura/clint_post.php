<?php
session_start();
require_once 'includes/db.php';

$clint_title = $_POST['clint_title'];
$clint_txt = $_POST['clint_txt'];
$clint_title_2nd = $_POST['clint_title_2nd'];
$clint_txt_2nd = $_POST['clint_txt_2nd'];
$clint_title_3rd = $_POST['clint_title_3rd'];
$clint_txt_3rd = $_POST['clint_txt_3rd'];

$clint_insert_query = "INSERT INTO `clients`(clint_title, clint_txt, clint_title_2nd, clint_txt_2nd, clint_title_3rd, clint_txt_3rd) VALUES ('$clint_title','$clint_txt','$clint_title_2nd','$clint_txt_2nd','$clint_title_3rd','$clint_txt_3rd')";
$clint_data = mysqli_query($db_connect,$clint_insert_query);
$_SESSION['clint_news'] = 'Clints review Update successfully';
header('location:restura_admin.php');



?>